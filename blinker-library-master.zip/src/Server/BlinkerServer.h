#ifndef BLINKER_SERVER_H
#define BLINKER_SERVER_H

#ifndef BLINKER_SERVER_HTTPS
    #define BLINKER_SERVER_HTTPS    "https://iot.diandeng.tech"
#endif

#ifndef BLINKER_SERVER_HOST
    #define BLINKER_SERVER_HOST     "iot.diandeng.tech"
#endif

#endif